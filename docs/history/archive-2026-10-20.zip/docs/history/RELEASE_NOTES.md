# Исторические записи разработки

Версии, source-only и unreleased ниже относятся к моменту записи, а не текущему
состоянию мода. Актуальное поведение — в CorpseProxyLab/README.md.

# Local: release obstructed train tails

Treat a train segment exceeding the existing 18-unit distance limit as a normal
release, rather than poisoning every link with a permanent solver failure.
The prefix remains active; the obstructed segment and descendants release through
the existing SP/server lifecycle. Original bodies and tether items remain intact.
Tests simulate a blocked middle body, root separation and returning the vehicle.
This does not add rope collision or prevent stretching up to the existing limit.

# Unreleased: linear corpse trains

Add vehicle -> corpse -> corpse towing, one item per segment, retaining parallel
vehicle attachments. Context-menu actions visit both bodies; the authoritative
server validates the source link UUID, ownership, free tail and capacity. Shared
bounded substeps use collision-resolved predecessor positions, and only taut
paths transmit load to the car. Branches and cycles are rejected.

Middle detach/deletion releases the tail. Persisted car membership also invalidates
unloaded descendants; temporary unload pauses the chain and restoration rebinds
persistent identities. New network protocol: 3. The native rope renderer now
supports a corpse source endpoint; the source Java helper has been rebuilt.
Installing this stage requires matching Lua/JAR files and a game/server restart.
No installed copy or release snapshot was changed by this task.

The user's multiplayer acceptance applies to the previous core stage. New train
behavior and long-tail camera visibility still require in-game acceptance. See
`tests/test_trains.py`, `tests/ValidateBodyRopeScene.java` and `outputs/train/` for
automated checks and comparison evidence.

# Unreleased: alpha core schema 2 and shared registry

Replace additive legacy migration with a single schema-2 tether record. Vehicle
and attachment point are stored only in connection endpoints. Old/malformed
bindings are discarded on discovery/read; the world corpse remains. Network
protocol is now 2: server and clients must use matching Lua.

SP/server share an active registry indexed by connection UUID, body and vehicle.
Server broadcasts build each active state once, then filter the snapshot for each
recipient. Movement, collision, load tuning and parallel towing are unchanged;
body-to-body towing is not included. Duplicate saved connection IDs are isolated
instead of aborting discovery.

Validation: all 27 Python test scripts pass in the current workspace. Thirty-six
SP/server motion/load comparisons against the previous core match frame-for-frame.
Coverage includes old/bad record reset, current-format reload, index lifecycle,
stale actions, and snapshot work counts at 0/8/64 links with four recipients.
Native B42 corpse serialization preserves schema 2 and its nested endpoints without
the removed vehicle/point fields. This is source only: no installed mod, release
package or running server was changed. Full world-load and live multiplayer
acceptance are still pending. Earlier unreleased sections below describe history,
not the current compatibility contract.

# Unreleased: connection identity and endpoints

Add a persistent UUID and two typed endpoints to each activated connection.
Existing schema-1 records are extended in place, keeping their original fields,
items and bodies. A body retains its own key; reattachment creates a new
connection ID. Only the existing vehicle-to-body mechanic is enabled.

State packets include the optional descriptor, and new detach requests identify
the intended connection. Stale actions/terminal states cannot release a later
connection with the same body and item. Native corpse IDs remain the transport
lookup keys; legacy packets without descriptors are still accepted.

Development reload staging now handles new shared files, including removal on a
rejected reload. Java runtime helpers, installed mods and release packages are
unchanged. This is a source-only development change.

Validation: all 25 Python test scripts pass, including 11 connection tests.
Thirty-six before/after comparisons (SP/server, feet/neck, all three materials,
30/60/120 FPS) retain identical per-frame motion/load values. The actual B42
corpse serializer preserves legacy fields, connection UUID and both nested
endpoint descriptors; the native UUID API is checked there as well.
Full world reload and live two-player acceptance remain pending.

# Unreleased: shared SP/server core

Extract shared tether metadata, item transfer and attachment/release operations,
saved-link resolution and movement into `CVP_Core.lua`. SP and server adapters
retain their existing validation, lifecycle policies, presentation and network
responsibilities. Save schema 1, SP runtime schema 2 and network protocol 1 stay
unchanged; no new gameplay mechanics or Java changes. Development reload tools
now stage the core dependency. Source only; not published or installed.

Validation: all 24 Python test scripts pass, including seven new lifecycle tests
with SP/server cases for legacy records, repeated restoration, transfer failures,
registration rollback, return conflicts and unchanged slot lengths. Eighteen
fixture comparisons against the pre-refactor adapters (three materials,
30/60/120 FPS, SP/server) produced identical per-frame motion/load values.
Transfer rollback also covers an exception during removal from the source
container. Native save-file and live two-player acceptance were not performed.

# Corpse Tow 0.1.5

0.1.5: Fix stale tether markers after multiplayer tracking loss; refresh corpse towing mass when loot changes; apply vehicle resistance progressively as tethers tighten; reduce multiplayer body lag relative to the vehicle hitch. 23 automated test scripts passed. Live two-player acceptance remains pending.

# Corpse Tow 0.1.4

0.1.4: Improved slack rope and chain movement when reversing toward bodies. Smooth rope rendering with 32 visual segments and 16 simulation segments; chains use 16 segments. Removed all mod-added towing and tying sounds. Locally tested and accepted in single-player. Dedicated-server multiplayer acceptance remains pending. No server restart performed.

# Corpse Tow 0.1.3 — public beta

## Published naming and cover update — 2026-10-20

Workshop and the main mod list entry now use **Corpse Tow [B42]**. The optional
adapter is **Corpse Tow - Viewpoint support**. Technical IDs remain
`CorpseProxyLab` and `CorpseProxyViewpoint`; Workshop ID remains `3823056494`.
The supplied CORPSE TOW cover is stored as `Workshop/preview.png`, with the
published JPEG in `Workshop/preview-upload.jpg` under `releases/0.1.3`.

The release directory, download ZIP and manifest reflect the published naming
update. English/Russian page descriptions and the successful Steam API response
are recorded alongside them. Gameplay files are unchanged. No new tests were run
for this update; validation results below belong to the earlier 0.1.3 release.

## 0.1.3 release checkpoint

This package includes the development features documented below: player corpses,
two-endpoint tying, vehicle batch actions, multiplayer controls, motion buffering,
native tether materials and sounds. The older "Unreleased" headings below describe
their implementation history; they are included in this release.

Rope curves no longer gain artificial velocity from moving attachments. Base.Rope
has damped stretch capped at 5% of length / 25 cm and gradual visual straightening.
Heavy chains retain rigid towing physics. The packaged CVP_Rope.lua is the accepted
fixed source, verified against the active local mod path.

Validation: all 21 Python test scripts and the native world, network, rope-render
and Viewpoint checks passed. Local rope motion was user-accepted. Complete live
two-endpoint walking/animation and two-player dedicated-server acceptance remain
pending. Historical validation notes below do not imply those checks are complete.

Update clients AND server together at the next maintenance window. Java helpers
and server Lua differ from 0.1.1; updated instances need restarting. Publishing
this package does not install it on an already running server.

## Unreleased: work at both tether endpoints

- Individual corpse action: approach the body, tie it, approach the hitch, tie
  the other end. The hitch uses the native VehicleTrailer animation and the
  same world attachment point as the rendered rope.
- Vehicle batch: select one item per body within the available capacity, tie
  all selected items at the hitch, then visit the bodies sequentially. No
  return trip to the hitch between bodies. Each completed body waits for its
  server acknowledgement before the next body is approached.
- Unfinished ties exist only in the local action sequence. Items stay in the
  player's inventory until the final validated attachment. Cancellation,
  unreachable paths, moved targets or missing equipment stop the remaining
  sequence without undoing already completed attachments.
- MP advertises `twoPointAttach`; older servers cannot run this client workflow.
  Server validation checks the final endpoint (body or hitch), item ownership,
  vehicle state, body range and capacity. Client and server must be updated together.
- Development sources only; not published or deployed by this change. Automated
  SP/MP tests cover stage order, cancellation, original inventory, acknowledgements
  and final endpoint validation. Live walking/animation acceptance is pending.

## Unreleased: multiplayer controls and movement

- Server physics limits incoming vehicle anchor corrections before rope integration.
  It allows temporary rope stretch while catching up; it does not change the engine's
  vehicle replication or remove all network latency. SP physics is unchanged.
- MP attach menu keeps unavailable actions visible with a reason (equipment,
  vehicle, seat, ownership, capacity or server policy).
- Nearby stopped vehicles offer a body count and vehicle-scoped bulk detach.
  Each original tether is returned independently; a failed transfer retains that
  body's attachment for retry. Server validation and replay protection apply.
  The MP command is enabled only when the server advertises support.
- Sandbox settings: `AllowPlayerCorpses=true`, `MaxBodiesPerVehicle=8` (1–8),
  `AllowDetachOthers=true`. Ownership restrictions apply to new MP attachments;
  legacy ownerless attachments remain detachable. Lower limits do not remove
  existing links. Disabling human corpses still permits their detachment.
- Source changes only: not published, installed or hot-loaded on the live server.
  No server restart performed. Isolated Lua regressions cover inventory rollback,
  ownership, capacity, bulk commands, UI and exact post-detach client convergence.
  Live dedicated-server performance and movement acceptance remain pending.

## Unreleased: player corpses

Source now permits non-animal human corpses, including dead players, in SP and MP.
Live characters and fake-dead zombies are excluded. The original world corpse and
its inventory are retained; the mod does not change its reanimation schedule.
Client and server changes must be deployed together. This feature is not included
in the published 0.1.1 snapshot and has not been installed on the running server.

## 0.1.1 changes

- Fix the multiplayer attach menu for Build 42's vehicle Set (no indexed get).
- Buffer nearby corpse positions for smoother multiplayer rendering; bound visual
  catch-up after abrupt server corrections. No extra network messages or server physics changes.
- Rendering adds 250 ms of delay and may stretch the visible rope while driving.
  Long packet gaps can still cause pauses. Floor changes and large teleports reset the buffer.
- Verified live on one connected client with two moving bodies at approximately 60 FPS;
  14 menu/network/interpolation regression checks pass. This is not an exhaustive performance guarantee.
- Java helpers are unchanged. No developer bridge is shipped. Update clients and server
  together at the next maintenance window; this publication does not update a running server.

Vehicle towing for ordinary zombie corpses in Project Zomboid **42.21.0**.
Single-player and experimental server-authoritative multiplayer. Requires
**ZombieBuddy 2.0+**, including its Java agent installation on every client and
the dedicated server. A Workshop subscription alone does not install the agent.

## Playing

Carry a rope, heavy chain or chain with hook. Exit the vehicle, stand near a
dead zombie and park the rear of the vehicle nearby. Right-click the body and
choose **Attach body**. To release it, approach on foot and choose **Detach body**.
The original tether item stays inside the original corpse until release. Loot
is retained. Multiple bodies increase vehicle resistance when their ropes are
taut; the sandbox option can disable that resistance.

The ropes render inside the native vehicle scene. Isometric view is supported.
The bundled **Corpse Proxy Lab - Viewpoint support** submod is optional: enable
it only when Viewpoint and its dependencies are installed.

## Multiplayer

- Core Mod ID: `CorpseProxyLab`.
- Optional adapter Mod ID: `CorpseProxyViewpoint`.
- The server owns attachment, detachment, inventory transfers and body movement.
- Clients receive nearby body state and render the ropes. Late arrivals request
  missing bodies from the server using the game's native corpse serialization.
- Maximum eight bodies per vehicle and 64 active tethers per server.
- Tethers persist in native body/vehicle save data and resume when both load.
- Nearby players may detach each other's tethers. There is no private ownership.
- Multiplayer attachment is currently immediate after server validation; the
  single-player timed approach animation is not yet implemented in multiplayer.
- Split-screen is unsupported. Two-player live acceptance is still pending.

## Dedicated server installation

1. Subscribe to this item and ZombieBuddy. Add their Workshop IDs to
   `WorkshopItems`, and `ZombieBuddy;CorpseProxyLab` to `Mods`, retaining existing
   entries. Use the Build 42 mod-ID format already used by your server config.
2. Follow ZombieBuddy's installation guide to enable its Java agent in the
   dedicated server JVM. For headless servers select `frontend=console` and
   explicitly approve this mod when prompted. Do not enable allow-all.
3. Keep Lua checksum checking enabled. Clients need the same mod versions and
   the ZombieBuddy Java agent. Restart game/server after a Java update.
4. If using Viewpoint, install its Workshop dependencies and enable the adapter
   consistently with the server mod list to avoid Lua checksum mismatches.

Do not combine this release with the earlier `CorpseTowMP` / `CorpseGrappleLab`
experiments. They are separate mods, not previous versions of this Workshop item.
The agent debug bridge, local test server, saves and credentials are excluded
from the public package.

## Validation and limitations

The Lua regression suite covers competing players, repeated/out-of-order
commands, inventory rollback, disconnect/reload, two simulated clients,
late-join bootstrap and malformed payloads. Native Java checks cover corpse
serialization, pose preservation, rendering transforms and installed Viewpoint
bindings. A local dedicated 42.21.0 server reached SERVER STARTED with the helper.
These checks are not a substitute for two real players testing together.

Bodies remain subject to normal decay and other mods. Collision uses a tile
footprint, not a rigid-body solver or rope wrapping. Abrupt process-crash
consistency across native save files is unverified. Back up an existing world
before enabling this public beta.

## Accepted local baseline — 2026-10-20

Historical checkpoint only. For the current implementation and test workflow, see [README](../../README.md) and [development guide](../DEVELOPMENT.md).

Unpublished development snapshot. No server deployment or restart is part of this checkpoint.

The user accepted rope motion and tension after live client hot patches:

- Endpoint transport no longer injects artificial velocity into the rope curve.
- Base.Rope has damped compliance, limited to 5% of length and at most 25 cm.
- Remaining bends straighten gradually at full tension, without delaying attachments.
- HeavyChain and HeavyChain_Hook retain rigid towing physics.

Regression checks cover 30/60/120 FPS, bounded stretch, settling, unchanged chain
motion, threshold continuity, attachment positions, ground contact and solver cost.
The last bridge check reported two intact tethers and approximately 60 FPS; this is
not a general performance guarantee or a dedicated-server acceptance test.

### What the checkpoint contains

Git records the complete current development source, built mod JARs, tests and
tools. Other existing development work is included as-is. In particular, the
two-endpoint tying workflow still has pending live walking/animation acceptance
(see ../RELEASE.md); accepting the rope changes does not certify every feature.

The separate backup contains the Git source archive and bundle, a copy of the
local installed mod directories and Workshop staging directory, and the local
bridge scripts/evidence. Installed files are preserved separately: they can differ
from source and from Lua functions replaced in the current game's memory.
It does not contain a backup of the multiplayer world.

### Returning to this checkpoint

1. Extract `source.zip` into a NEW empty folder to recover the exact development
   tree. Alternatively clone `repository.bundle` and select the checkpoint tag
   recorded in `BACKUP.json`. Do not reset an existing checkout with newer work.
2. `local-files.zip` preserves each local path under a named archive root; its
   mapping and SHA-256 manifest are in `BACKUP.json`. Restore those files only
   with the game closed, after copying aside the then-current installation.
3. The accepted hot changes are also in `runtime-evidence.zip`: the builders
   `build-rope-stability.py` and `build-rope-elasticity.py` generate scripts from
   the restored source. `apply-rope-stability.lua` replaces only seed/shape;
   `apply-rope-elasticity.lua` replaces only step on the local SP CVPTest.rope
   table. They require the existing local bridge and must not be sent to an
   unrelated session or a multiplayer server. The captured scripts are evidence,
   not an automatic startup installer.
4. A future complete source installation requires the usual client/Java reload
   and separate acceptance of pending features. Do not assume that restoring
   files restores live Lua memory. No restore, restart or publication was done
   when creating this backup.
