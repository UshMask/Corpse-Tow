# Local: per-train capacity

Default 32 bodies per independent vehicle-rooted train; MaxBodiesPerChain=0
removes the limit. Independent roots do not consume one another's capacity.
The old vehicle-wide option and global 64-link server cap no longer apply.
Existing longer trains remain valid when the configured limit is lowered.
Traversal and restore use visited identities instead of eight-body cutoffs.
Tail invalidation uses an adjacency walk; load propagation is linear per substep.
No publication or server deployment performed.

# Corpse Tow 0.1.6 — alpha

This release includes the core, chain and renderer work described in the historical
implementation notes below. Their "Local", "Unreleased" and "source-only" labels
describe the earlier development checkpoints.

- Linear vehicle-to-body-to-body towing, sequential attachment and nearest-tail
  actions, with working tether lengths fitted at attachment.
- Context menus follow the clicked body/vehicle or nearby targets, with material
  selection, highlights and disabled-action explanations shared by SP and MP.
- Smoother chain substeps and resistance transmitted through simultaneously taut
  links. Obstructed, overstretched tails release without freezing the prefix.
- Single-player vehicle resistance now works when the engine reports Server
  authorization; multiplayer ownership checks are retained.
- Safer inventory transfers when another mod refuses or redirects item removal.
- Body-endpoint rendering, lighter tether meshes and renderer scratch reuse.
- Separate local/Steam launchers and local installation checks are included in Git;
  developer bridges, launchers and source files are excluded from Workshop content.

Upgrade from 0.1.5: save schema 2 and network protocol 3 require matching updated
clients and server. Legacy tether records are discarded; original world bodies and
tether items are retained by the reset path. Back up the world before upgrading.
Completely restart updated games/servers to load the new Java helper, and approve
its changed JAR in ZombieBuddy when prompted. Publishing does not update a running
server or install the local development build.

Validation: all 34 Python test scripts and five native game/Viewpoint checks passed
on the frozen release source. Live old-world save/restart acceptance and the new
train behavior with two real players remain unverified.

## Текущая установка и проверка

Описание поведения: [README мода](../CorpseProxyLab/README.md). Подготовка и запуск
тестов: [проверки](DEVELOPMENT.md#проверки). Исторические записи:
[история разработки](history/RELEASE_NOTES.md).
Пакеты releases/ сохранены как снимки и не обновляются вместе с рабочим деревом.

Для локальной проверки используется пункт «Локальный тест» в `Мод.cmd`; публикация Workshop
и обновление сервера не являются частью этого действия.

Для отдельной установки на сервер нужны ZombieBuddy с Java-агентом и
CorpseProxyLab на сервере и клиентах, совпадающие версии Lua/JAR и сохранённые
настройки Lua checksum. Workshop ID основного мода — 3823056494; ZombieBuddy —
3619862853. Состав WorkshopItems/Mods меняется только в рамках отдельного обновления
сервера. После замены Java нужен полный перезапуск соответствующего процесса.
Viewpoint-адаптер необязателен и требует Viewpoint; его состав согласуется с
конкретной конфигурацией сервера/клиентов.

MP использует подход и действия у концов троса, подтверждения сервера и
проверку UUID. Разрешения на чужие привязки и тела игроков настраиваются.
Утверждения в старых записях о мгновенной привязке и отсутствии прав доступа
не описывают текущую реализацию. Полная игровая проверка двумя игроками
отличается от запуска сервера и тестов на модели движка.
