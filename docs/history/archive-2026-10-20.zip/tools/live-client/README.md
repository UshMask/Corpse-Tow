# Local live client Lua bridge

Development tool attached explicitly to the running **client PID**, never the dedicated server.
No listening socket, server commands, Workshop modifications, checksum changes or startup installation.
The bridge polls a local directory every 200 ms on `GameWindow.logic` and executes one consumed Lua
request through `LuaManager.caller.pcall`. Requests can execute arbitrary Lua with the client's rights;
only use your own scripts. It does not grant server privileges.

The current attachment ends when the client exits. Reconnecting and restarting are not equivalent:
a Lua environment reset can remove a runtime patch. Always probe before applying again.

## Build and attach

Compile `LocalLuaBridge.java` and `Attach.java` with JDK 25. The compilation classpath needs
the game directory, `projectzomboid.jar`, and the installed `ZombieBuddy.jar` (ByteBuddy).
Package classes with manifest entries:

```
Agent-Class: cvplocal.LocalLuaBridge
Can-Retransform-Classes: true
```

Attach with `java --add-modules jdk.attach -cp <classes> Attach <client-pid> <absolute-jar> <absolute-request-directory>`.
Confirm the PID belongs to `ProjectZomboid64`, not a server. Do not automatically retry attachment.
`attached.txt` confirms attachment; a successful read-only Lua response confirms the game-thread hook.

## Requests

From the repository root, `python tools/live-client/request.py <script.lua>` uses `outputs/live-client`.
One writer at a time. A timeout is ambiguous: inspect the response and pending request before retrying.
The fixed directory is local developer control, not a multiplayer command transport.

## Updating mod code

Use the local installer with the game closed, then restart. The obsolete menu
hotfix generator, probe and rollback were removed: its extracted callback missed
module dependencies and could replace the working menu with a broken callback.
Do not execute previously generated menu-fix.lua files left in outputs/backups.
Old versions remain available in Git history as evidence, not an update workflow.

The old prepare_motion_fix.py / rollback-motion.lua files are historical helpers,
not the supported update path for current clients. Do not reload the entire MP
module in-session: its anonymous event handlers can be registered twice.
For normal development use tools/Local-Mod.ps1; for deliberate SP-only module
reloads see CVPAgent/README.md and its schema/active-action restrictions.

## Motion diagnostics

`measure-motion.lua` temporarily wraps client receive/tick for diagnostics. `motion-result.lua`
returns elapsed ms, active links, packet count, maximum gap ms, tick count, moving body-ticks,
maximum frame displacement, external displacement, total measured tick ms, and current FPS.
Restore the wrapped functions and clear `CVPMotionMeasure` when finished.
