# Corpse Proxy Lab — Viewpoint support 0.0.5

Requires CorpseProxyLab, Viewpoint and ZombieBuddy. Bundled as an optional submod
with CorpseProxyLab; its own version is independent of the core release. The Java adapter loads on clients only.

Ropes are native scene model geometry, shared with the isometric renderer. The VehicleCapture hook uses the actual vehicle placement matrix for the current Frame, including VehicleAhead and terrain tilt. It rebases only our rope snapshot entries so the bumper stays rigidly attached while the other end remains with the world corpse. No rope screen projection, UI overlay, separate framebuffer, or custom camera matrix is used. Viewpoint's regular model depth, lighting and temporal passes consume the segments.

WorldText projection remains available only for bridge diagnostics; it no longer draws the rope. Existing corpse pose correction is preserved.

Build with `powershell -NoProfile -File tools/Build.ps1 -Viewpoint` from the project root. Tests validate native mesh parsing, coordinate transforms, segment endpoints, pooled corpse poses and installed Viewpoint bindings. This adapter accesses private VehicleCapture placement and is version-sensitive. The updated JARs loaded successfully on 2026-10-19 and native rope geometry was visually observed. Parked first/third-person A/B/A performance samples and 22 abrupt-camera transform checks passed. See the core README for measured FPS and limits: seated first-person attachment points are occluded by the cabin, and sub-frame jitter while driving is not established by endpoint telemetry.

Completely restart the game after installing the core and adapter JARs, approve the updates in ZombieBuddy if prompted, and load the test save. Use `scene-status` and `tools/benchmark_scene_rope.py` for separate isometric/first/third-person checks.

Current test setup and isolated native validation: see docs/DEVELOPMENT.md.
The dated measurements above are historical observations, not current FPS guarantees.
